from django.apps import AppConfig


class ChauffeurConfig(AppConfig):
    name = 'Chauffeur'
