from operator import mod
from django.db import models