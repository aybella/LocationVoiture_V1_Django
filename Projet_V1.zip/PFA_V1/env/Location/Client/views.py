from django.shortcuts import render
# Create your views here.
def Accueil(request):
    return render(request,'Client/Accueil.html')